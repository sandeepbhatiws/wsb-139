

function test (){
    console.log('Test');
}


// document.getElementById('button').addEventListener('click',test);


document.getElementById('button').addEventListener('click',() => {
    console.log('Welcome');
});



// console.log('Hello');